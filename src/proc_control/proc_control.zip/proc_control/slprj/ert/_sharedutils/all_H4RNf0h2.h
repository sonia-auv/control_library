//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: all_H4RNf0h2.h
//
// Code generated for Simulink model 'proc_control'.
//
// Model version                  : 3.1
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Apr  7 23:11:26 2022
//
#ifndef RTW_HEADER_all_H4RNf0h2_h_
#define RTW_HEADER_all_H4RNf0h2_h_
#include "rtwtypes.h"

extern void all_H4RNf0h2(const boolean_T x[130], boolean_T y[13]);

#endif                                 // RTW_HEADER_all_H4RNf0h2_h_

//
// File trailer for generated code.
//
// [EOF]
//
