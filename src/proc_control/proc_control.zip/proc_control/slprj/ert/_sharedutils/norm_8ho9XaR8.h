//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: norm_8ho9XaR8.h
//
// Code generated for Simulink model 'proc_control'.
//
// Model version                  : 3.1
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Apr  7 23:11:26 2022
//
#ifndef RTW_HEADER_norm_8ho9XaR8_h_
#define RTW_HEADER_norm_8ho9XaR8_h_
#include "rtwtypes.h"

extern real_T norm_8ho9XaR8(const real_T x[17]);

#endif                                 // RTW_HEADER_norm_8ho9XaR8_h_

//
// File trailer for generated code.
//
// [EOF]
//
