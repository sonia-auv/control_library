//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: binsearch_u32d_prevIdx.h
//
// Code generated for Simulink model 'proc_control'.
//
// Model version                  : 3.1
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Apr  7 23:11:26 2022
//
#ifndef RTW_HEADER_binsearch_u32d_prevIdx_h_
#define RTW_HEADER_binsearch_u32d_prevIdx_h_
#include "rtwtypes.h"

extern uint32_T binsearch_u32d_prevIdx(real_T u, const real_T bp[], uint32_T
  startIndex, uint32_T maxIndex);

#endif                                 // RTW_HEADER_binsearch_u32d_prevIdx_h_

//
// File trailer for generated code.
//
// [EOF]
//
