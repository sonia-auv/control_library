//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: trisolve_3zyRfoj9.h
//
// Code generated for Simulink model 'proc_control'.
//
// Model version                  : 3.1
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Apr  7 23:11:26 2022
//
#ifndef RTW_HEADER_trisolve_3zyRfoj9_h_
#define RTW_HEADER_trisolve_3zyRfoj9_h_
#include "rtwtypes.h"

extern void trisolve_3zyRfoj9(const real_T A[81], real_T B[117]);

#endif                                 // RTW_HEADER_trisolve_3zyRfoj9_h_

//
// File trailer for generated code.
//
// [EOF]
//
