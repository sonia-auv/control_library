//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: plook_u32u16_binckpan.h
//
// Code generated for Simulink model 'proc_control'.
//
// Model version                  : 3.1
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Apr  7 23:11:26 2022
//
#ifndef RTW_HEADER_plook_u32u16_binckpan_h_
#define RTW_HEADER_plook_u32u16_binckpan_h_
#include "rtwtypes.h"

extern uint32_T plook_u32u16_binckpan(uint16_T u, const uint16_T bp[], uint32_T
  maxIndex, uint32_T *prevIndex);

#endif                                 // RTW_HEADER_plook_u32u16_binckpan_h_

//
// File trailer for generated code.
//
// [EOF]
//
