//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: trisolve_nzh2XTxC.h
//
// Code generated for Simulink model 'proc_control'.
//
// Model version                  : 3.1
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Apr  7 23:11:26 2022
//
#ifndef RTW_HEADER_trisolve_nzh2XTxC_h_
#define RTW_HEADER_trisolve_nzh2XTxC_h_
#include "rtwtypes.h"

extern void trisolve_nzh2XTxC(const real_T A[9], real_T B[39]);

#endif                                 // RTW_HEADER_trisolve_nzh2XTxC_h_

//
// File trailer for generated code.
//
// [EOF]
//
