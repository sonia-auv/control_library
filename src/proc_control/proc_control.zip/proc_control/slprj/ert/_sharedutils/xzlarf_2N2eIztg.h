//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: xzlarf_2N2eIztg.h
//
// Code generated for Simulink model 'proc_control'.
//
// Model version                  : 3.1
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Apr  7 23:11:26 2022
//
#ifndef RTW_HEADER_xzlarf_2N2eIztg_h_
#define RTW_HEADER_xzlarf_2N2eIztg_h_
#include "rtwtypes.h"

extern void xzlarf_2N2eIztg(int32_T m, int32_T n, int32_T iv0, real_T tau,
  real_T C[169], int32_T ic0, real_T work[13]);

#endif                                 // RTW_HEADER_xzlarf_2N2eIztg_h_

//
// File trailer for generated code.
//
// [EOF]
//
