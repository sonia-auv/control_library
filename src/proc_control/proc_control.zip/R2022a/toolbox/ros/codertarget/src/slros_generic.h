/* Copyright 2015-2018 The MathWorks, Inc. */

#ifndef _SLROS_GENERIC_H_
#define _SLROS_GENERIC_H_

// Include code for publisher and subscriber
#include "slros_generic_pubsub.h"

// Include code for getting and setting parameters
#include "slros_generic_param.h"

#endif
